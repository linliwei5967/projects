import React from 'react';

class NotFound extends React.Component {
  render() {
    return (
      <div className="not-found">
        <h2>Not Found Page</h2>
      </div>
    )}
}


export default NotFound;
